java -cp lib/xalan.jar:lib/serializer.jar:lib/xml-apis.jar:lib/xercesImpl.jar org.apache.xalan.xsltc.cmdline.Compile -j lib/cb2xml2cobol2j.jar -p net.sf.cobol2j.translets cb2xml2cobol2j.xsl
